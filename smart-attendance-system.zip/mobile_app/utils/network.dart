import 'dart:io';

Future<bool> checkNetwork() async {
  final allowedSSID = "Campus_WiFi"; // Replace with your campus SSID
  try {
    final result = await InternetAddress.lookup("192.168.0.1");
    if (result.isNotEmpty) {
      return true;
    }
  } catch (e) {
    return false;
  }
  return false;
}
