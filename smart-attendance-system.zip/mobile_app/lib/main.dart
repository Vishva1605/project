import 'package:flutter/material.dart';
import 'login.dart';

void main() {
  runApp(SmartAttendanceApp());
}

class SmartAttendanceApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Smart Attendance',
      home: LoginPage(),
    );
  }
}
