# Smart Attendance System

## 📌 Modules
1. **Mobile App (Flutter)** → Student login & face recognition
2. **Backend (Django)** → Attendance API & database
3. **Face Recognition (OpenCV, Python)** → Train & verify faces
4. **Admin Dashboard (React.js)** → View reports

## 🚀 Setup
- Run `flutter run` inside `mobile_app`
- Start backend: `python manage.py runserver`
- Start face recognition service: `python recognize_face.py`
- Start dashboard: `npm start` inside `admin_dashboard`
