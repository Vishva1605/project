import cv2, os, numpy as np

data_path = 'dataset/'
faces, labels = [], []
label_map = {}

for i, student in enumerate(os.listdir(data_path)):
    label_map[i] = student
    for img_name in os.listdir(os.path.join(data_path, student)):
        img = cv2.imread(os.path.join(data_path, student, img_name), 0)
        faces.append(img)
        labels.append(i)

face_recognizer = cv2.face.LBPHFaceRecognizer_create()
face_recognizer.train(faces, np.array(labels))
face_recognizer.save("face_model.yml")
