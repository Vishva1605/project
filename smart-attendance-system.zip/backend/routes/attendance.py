from django.http import JsonResponse
from .models.student import Student
from .models.attendance import Attendance
import datetime

def mark_attendance(request, student_id):
    today = datetime.date.today()
    student = Student.objects.get(id=student_id)
    Attendance.objects.create(student=student, date=today, status=True)
    return JsonResponse({"message": "Attendance marked"})
