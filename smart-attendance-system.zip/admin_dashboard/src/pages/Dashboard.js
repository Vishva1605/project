import React, { useEffect, useState } from "react";

function Dashboard() {
  const [attendance, setAttendance] = useState([]);

  useEffect(() => {
    fetch("http://localhost:8000/api/attendance")
      .then(res => res.json())
      .then(data => setAttendance(data));
  }, []);

  return (
    <div>
      <h1>Attendance Records</h1>
      <table>
        <tr><th>Student</th><th>Date</th><th>Status</th></tr>
        {attendance.map((a, i) => (
          <tr key={i}>
            <td>{a.student}</td>
            <td>{a.date}</td>
            <td>{a.status ? "Present" : "Absent"}</td>
          </tr>
        ))}
      </table>
    </div>
  );
}

export default Dashboard;
